package com.endlesscr.examplemod;

import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public class CursorManager {
    public static int normalX = 0, normalY = 0;
    public static int pointerX = 12, pointerY = 0;
    private static boolean isHidden = false;

    public static void initCursors() {
        if (isHidden) return;
        
        long window = Minecraft.getInstance().getWindow().getWindow();
        GLFW.glfwSetInputMode(window, GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_HIDDEN);
        
        isHidden = true;
    }
}
