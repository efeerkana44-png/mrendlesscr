package com.endlesscr.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.OptionsScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "endlesscr", value = Dist.CLIENT)
public class CursorEventHandler {

    private static final ResourceLocation NORMAL_TEX = new ResourceLocation("endlesscr", "textures/gui/cursor_normal.png");
    private static final ResourceLocation POINTER_TEX = new ResourceLocation("endlesscr", "textures/gui/cursor_pointer.png");

    @SubscribeEvent
    public static void onScreenRender(ScreenEvent.Render.Post event) {
        Screen screen = event.getScreen();
        if (screen == null) return;

        Minecraft mc = Minecraft.getInstance();
        
        double mouseX = mc.mouseHandler.xpos() * (double)screen.width / (double)mc.getWindow().getWidth();
        double mouseY = mc.mouseHandler.ypos() * (double)screen.height / (double)mc.getWindow().getHeight();

        boolean overButton = false;
        for (var renderable : screen.renderables) {
            if (renderable instanceof AbstractWidget widget) {
                if (widget.active && widget.visible && widget.isHoveredOrFocused()) {
                    overButton = true;
                    break;
                }
            }
        }

        GuiGraphics graphics = event.getGuiGraphics();
        ResourceLocation textureToDraw = overButton ? POINTER_TEX : NORMAL_TEX;
        
        int offsetX = overButton ? CursorManager.pointerX : CursorManager.normalX;
        int offsetY = overButton ? CursorManager.pointerY : CursorManager.normalY;

        int renderX = (int)mouseX - offsetX;
        int renderY = (int)mouseY - offsetY;

        graphics.blit(textureToDraw, renderX, renderY, 0, 0, 16, 16, 16, 16);
    }

    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.InitScreenEvent.Post event) {
        if (event.getScreen() instanceof OptionsScreen optionsScreen) {
            event.addListener(Button.builder(
                Component.literal("Mouse Hotspot"), 
                button -> {
                    Minecraft.getInstance().setScreen(new HotspotConfigScreen(optionsScreen));
                }
            )
            .bounds(optionsScreen.width / 2 - 155, optionsScreen.height / 6 + 24 - 6, 150, 20)
            .build());
        }
    }
}
