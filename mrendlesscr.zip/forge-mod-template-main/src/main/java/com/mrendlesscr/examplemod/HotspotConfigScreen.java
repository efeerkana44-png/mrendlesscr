package com.endlesscr.examplemod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public class HotspotConfigScreen extends Screen {
    private final Screen lastScreen;
    private final ResourceLocation normalCursorTex = new ResourceLocation("endlesscr", "textures/gui/cursor_normal.png");
    private final ResourceLocation pointerCursorTex = new ResourceLocation("endlesscr", "textures/gui/cursor_pointer.png");
    private boolean adjustingPointer = false;

    public HotspotConfigScreen(Screen lastScreen) {
        super(Component.literal("Mouse Hotspot Ayarlari"));
        this.lastScreen = lastScreen;
    }

    @Override
    protected void init() {
        this.addRenderableWidget(Button.builder(Component.literal("Kaydet ve Kapat"), button -> {
            this.minecraft.setScreen(this.lastScreen);
        }).bounds(this.width / 2 - 75, this.height - 40, 150, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("Mod Degistir: " + (adjustingPointer ? "Tiklama Eli" : "Normal Ok")), button -> {
            this.adjustingPointer = !this.adjustingPointer;
            button.setMessage(Component.literal("Mod Degistir: " + (adjustingPointer ? "Tiklama Eli" : "Normal Ok")));
        }).bounds(this.width / 2 - 75, 40, 150, 20).build());
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(guiGraphics);
        super.render(guiGraphics, mouseX, mouseY, partialTick);

        int imageSize = 32; 
        int scale = 4; 
        int renderSize = imageSize * scale;
        int x = this.width / 2 - (renderSize / 2);
        int y = this.height / 2 - (renderSize / 2);

        ResourceLocation currentTex = adjustingPointer ? pointerCursorTex : normalCursorTex;
        guiGraphics.blit(currentTex, x, y, 0, 0, imageSize, imageSize, renderSize, renderSize);

        int currentX = adjustingPointer ? CursorManager.pointerX : CursorManager.normalX;
        int currentY = adjustingPointer ? CursorManager.normalY : CursorManager.normalY;
        
        int markerX = x + (currentX * scale);
        int markerY = y + (currentY * scale);
        guiGraphics.fill(markerX, markerY, markerX + scale, markerY + scale, 0xFFFF0000);

        guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, 15, 0xFFFFFF);
        guiGraphics.drawCenteredString(this.font, "Gorsel uzerine tiklayarak tiklama merkezini (Hotspot) secin.", this.width / 2, 70, 0xAAAAAA);
        guiGraphics.drawCenteredString(this.font, "Aktif Hotspot X: " + currentX + " | Y: " + currentY, this.width / 2, 85, 0x55FF55);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int imageSize = 32;
        int scale = 4;
        int renderSize = imageSize * scale;
        int x = this.width / 2 - (renderSize / 2);
        int y = this.height / 2 - (renderSize / 2);

        if (mouseX >= x && mouseX < x + renderSize && mouseY >= y && mouseY < y + renderSize) {
            int clickedX = (int) ((mouseX - x) / scale);
            int clickedY = (int) ((mouseY - y) / scale);

            if (adjustingPointer) {
                CursorManager.pointerX = clickedX;
                CursorManager.pointerY = clickedY;
            } else {
                CursorManager.normalX = clickedX;
                CursorManager.normalY = clickedY;
            }
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }
}
