package com.endlesscr.examplemod;

import com.mojang.logging.LogUtils;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(ExampleMod.MOD_ID)
public class ExampleMod {

    // Mod kimliğini senin istediğin gibi "endlesscr" olarak sabitledik kanka
    public static final String MOD_ID = "endlesscr"; 
    public static final Logger LOGGER = LogUtils.getLogger();

    public ExampleMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        // İmleç çizici event dinleyicimizi Forge sistemine kaydettik
        MinecraftForge.EVENT_BUS.register(CursorEventHandler.class);
    }

    // Oyun sadece İstemci (Client/Oyuncu ekranı) olarak başladığında tetiklenen sınıf
    @Mod.EventBusSubscriber(modid = MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientModEvents {

        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event) {
            // Oyun arayüzü yüklenirken donanımsal fareyi gizleyen kodu tetikliyoruz
            event.enqueueWork(CursorManager::initCursors);
            LOGGER.info("Endless Cursor modu başarıyla yüklendi, fare imleci gizlendi!");
        }
    }
}
